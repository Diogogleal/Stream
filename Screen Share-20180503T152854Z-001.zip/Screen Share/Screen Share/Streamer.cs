﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RDPCOMAPILib;

namespace Screen_Share
{
    public partial class Streamer : Form
    {
        public Streamer()
        {
            InitializeComponent();

            pictureBox1.Image = Properties.Resources.help;         
        }

        public static class GlobalVars
        {
            public static bool conState = false;
        }

        RDPSession x = new RDPSession();

        private void Incoming(object Guest)
        {
            IRDPSRAPIAttendee MyGuest = (IRDPSRAPIAttendee)Guest;
            MyGuest.ControlLevel = CTRL_LEVEL.CTRL_LEVEL_VIEW;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            x.OnAttendeeConnected += Incoming;
            x.Open();
            MessageBox.Show("Connection started successfully");
            GlobalVars.conState = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (GlobalVars.conState == false)
            {
                MessageBox.Show("Start a connection first");
            }
            else
            {
                IRDPSRAPIInvitation Invitation = x.Invitations.CreateInvitation("Trial", "MyGroup", "", 10);
                textBox1.Text = Invitation.ConnectionString;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(GlobalVars.conState == true)
            {
                x.Close();
                x = null;
                MessageBox.Show("Connection ended successfully");
                GlobalVars.conState = false;
            }
            else
            {
                MessageBox.Show("Start a connection first");
            }            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1. Click 'Start Connection'\n2. Click 'Create Invite'\n3. Send the invite for the viewer");
        }
    }
}
