﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Screen_Share
{
    public partial class Viewer : Form
    {
        public Viewer()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Invitation = textBox1.Text;
            axRDPViewer1.Connect(Invitation, "User1", "");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            axRDPViewer1.Disconnect();
        }
    }
}
