﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Viewer
{
    public partial class Viewer : Form
    {
        public Viewer()
        {
            InitializeComponent();

            axRDPViewer1.Size = new System.Drawing.Size(Screen.PrimaryScreen.WorkingArea.Width - 192, Screen.PrimaryScreen.WorkingArea.Height - 60);

            pictureBox1.Image = Properties.Resources.help;
        }

        public static class GlobalVars
        {
            public static bool conState = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Insert the invite code");
            }
            else
            {
                string Invitation = textBox1.Text;
                axRDPViewer1.Connect(Invitation, "User1", "");
                MessageBox.Show("Connection started successfully");
                GlobalVars.conState = true;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (GlobalVars.conState == true)
            { 
                axRDPViewer1.Disconnect();
                MessageBox.Show("Connection ended successfully");
                GlobalVars.conState = false;
            }
            else
            {
                MessageBox.Show("Start a connection first");
            }
        }

        private void Viewer_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Left = Top = 0;
            this.Width = Screen.PrimaryScreen.WorkingArea.Width;
            this.Height = Screen.PrimaryScreen.WorkingArea.Height;
        }

        private void axRDPViewer1_Enter(object sender, EventArgs e)
        {
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            panel1.Left = 1188;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1. Insert given invitation\n2. Click 'Connect'");
        }
    }
}
